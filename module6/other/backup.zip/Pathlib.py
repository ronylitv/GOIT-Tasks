import shutil
from pathlib import Path
p = Path.cwd()
path_arch = shutil.make_archive('backup', 'zip', p)
print(path_arch)